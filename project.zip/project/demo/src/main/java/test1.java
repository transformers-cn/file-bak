import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.json.JSONObject;

public class test1 {

    private static final String BASE_URL = "host-URL";
    private static final String USER_ID = "user-ID";
    private static final String PASSWORD = "password";
    private static final String CERT_FILE = "path_and_filename_to_certification_file";

    public static void main(String[] args) {
        try {
            String accessToken = getAccessToken(BASE_URL);
            // Use the access token to make further API requests
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Function to get access token
    public static String getAccessToken(String baseUrl) throws IOException {
        String url = baseUrl + "/SASLogon/oauth/token";
        String credentials = "client-ID:client-secret";
        String encodedCredentials = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Authorization", "Basic " + encodedCredentials);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        String urlParameters = "grant_type=password&username=" + USER_ID + "&password=" + PASSWORD;

        // Send post request
        con.setDoOutput(true);
        try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
            wr.writeBytes(urlParameters);
        }

        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());
            return jsonResponse.getString("access_token");
        } else {
            System.out.println("Failed to get access token. HTTP error code: " + responseCode);
            return null;
        }
    }

    // Function to perform GET request
    public static String get(String url, String accessToken, String accept) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", accept);
        con.setRequestProperty("Authorization", "Bearer " + accessToken);

        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } else {
            System.out.println("GET request failed. HTTP error code: " + responseCode);
            return null;
        }
    }

    // Function to perform POST request
    public static String post(String url, String contentType, String accept, String accessToken, String body) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept", accept);
        con.setRequestProperty("Authorization", "Bearer " + accessToken);
        con.setRequestProperty("Content-Type", contentType);

        // Send post request
        con.setDoOutput(true);
        try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
            wr.writeBytes(body);
        }

        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } else {
            System.out.println("POST request failed. HTTP error code: " + responseCode);
            return null;
        }
    }

    // Function to perform PUT request
    public static String put(String url, String contentType, String accept, String accessToken, String conditionalPutKey, String conditionalPutValue, String body) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("PUT");
        con.setRequestProperty("Accept", accept);
        con.setRequestProperty("Authorization", "Bearer " + accessToken);
        con.setRequestProperty("Content-Type", contentType);

        if (conditionalPutKey != null && conditionalPutValue != null) {
            con.setRequestProperty(conditionalPutKey, conditionalPutValue);
        }

        // Send put request
        con.setDoOutput(true);
        try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
            wr.writeBytes(body);
        }

        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } else {
            System.out.println("PUT request failed. HTTP error code: " + responseCode);
            return null;
        }
    }
}