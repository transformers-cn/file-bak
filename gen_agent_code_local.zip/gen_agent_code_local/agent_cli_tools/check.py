import requests
from config import config

def check_agent_script(name, script, check_tool=False):
    """
    校验智能体脚本是否可正常运行
    
    Args:
        name: 智能体名称
        script: 智能体脚本内容
        check_tool: 是否检查智能体依赖的工具是否存在
    """
    url = config.get_url("/check")
    
    payload = {
        "name": name,
        "script": script,
        "checkTool": check_tool
    }
    
    response = requests.post(url, json=payload, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 200:
            data = result.get("data", {})
            if data.get("success") is False:
                raise Exception(f"Agent Script Error: {data.get('message', 'Unknown error')}")
            return data
        else:
            raise Exception(f"API Error: {result.get('message', 'Unknown error')}")
    else:
        response.raise_for_status()