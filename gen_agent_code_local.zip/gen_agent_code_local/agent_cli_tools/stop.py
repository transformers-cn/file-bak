import requests
from config import config

def stop_agent(request_id):
    """停止指定 requestId 对应的智能体执行"""
    url = config.get_url("/stop")
    params = {"requestId": request_id}
    
    response = requests.post(url, params=params, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()