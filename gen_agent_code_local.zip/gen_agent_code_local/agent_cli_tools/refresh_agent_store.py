import json
from typing import Any, Dict, List, Optional

import requests
from config import config


REFRESH_URL = "http://172.18.2.14:5171/api/agent-store/refresh"


def refresh_agent_store(
    agent_name_list: List[str],
    tag: str = "",
    refresh_mode: Optional[Any] = None,
    delete_flag: bool = False,
    personal: Optional[bool] = None,
) -> Dict[str, Any]:
    """
    刷新 Agent Store（对应 /api/agent-store/refresh）。

    Returns:
        接口返回的 JSON（尽量原样透传）。
    """
    url = config.get_url("/refresh")
    headers = config.get_headers()
    headers["Content-Type"] = "application/json"
    print(headers)
    if personal is None:
        personal = config.personal
    body = {
        "agentNameList": agent_name_list,
        "tag": tag,
        "refreshMode": refresh_mode,
        "deleteFlag": delete_flag,
        "personal": personal,
    }

    # 使用 data 而非 json=，以贴近你给的 fetch 示例（body 是字符串）。
    response = requests.post(url,headers=headers, data=json.dumps(body), timeout=60,)

    try:
        result = response.json()
    except Exception:
        # 如果返回不是 JSON，仍然给出可诊断信息
        response.raise_for_status()
        raise
    print(f"接口响应: {result}")
    if response.status_code != 200:
        response.raise_for_status()

    # 尽量兼容不同接口 code 约定（有的用 0，有的用 200）
    if isinstance(result, dict) and "code" in result:
        code = result.get("code")
        if code not in (0, 200):
            raise Exception(f"API Error: {result.get('msg') or result.get('message') or result}")

    return result


def main() -> None:
    # 默认按你的示例 agentNameList
    agent_name_list = ["agt_powershell.codex"]

    result = refresh_agent_store(agent_name_list=agent_name_list)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
