import requests
from config import config

def download_agent(agent_name):
    """下载指定 Agent，返回脚本内容"""
    url = config.get_url("/download")
    params = {"agentName": agent_name}
    
    response = requests.get(url, params=params, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()