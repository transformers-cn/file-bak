import requests
from config import config

def generate_agent(requirement, agent_name=None):
    """
    使用 agt_agent_gen.template 根据需求生成新的 Agent
    
    Args:
        requirement: 生成需求描述
        agent_name: 期望的 Agent 名称（用于约束生成结果）
    """
    url = config.get_url("/gen")
    
    payload = {
        "requirement": requirement
    }
    
    if agent_name:
        payload["agentName"] = agent_name
    
    response = requests.post(url, json=payload, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()