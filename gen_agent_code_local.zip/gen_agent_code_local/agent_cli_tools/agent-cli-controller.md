# Agent CLI API 说明

**基础路径**：`/agent-cli`  
**服务入口**：以 agent-runtime-starter 为例，默认端口 **8180**（Undertow），无前缀时完整 base URL 为 `http://localhost:8180/agent-cli`。

**请求格式**：POST 接口请求体为 JSON，请设置 `Content-Type: application/json`。

**返回格式**：所有接口统一返回 `BaseResult<T>`，其中：
- `code`：业务状态码（`0` 一般表示成功，非 `0` 表示失败）
- `msg`：提示信息（失败时通常为错误原因）
- `data`：实际业务数据（失败时可能为 `null`）

---

## 典型调用流程

- **运行并取结果**：`GET /gen-request-id` 获取 `requestId`（可选，不传则由服务端生成）→ `POST /run` 传入 `agentName` 等（**同步执行**，返回即表示当次执行结束）→ 从响应中取 `agentResult`。
- **控制会话**：`GET /status-running` 查看运行中会话 → `POST /suspend` 或 `POST /stop` 传入对应 `requestId`。
- **调试/生成 Agent**：`POST /check` 校验脚本 → `POST /upload` 上传 → `POST /run` 运行；或 `POST /gen` / `POST /debug` 生成/改进脚本后再上传、运行。验证阶段同样可结合 `GET /status`、`GET /query-result`、`GET /inspect` 做结果与中间态校验。
- **验证**：用 `GET /status` 确认状态、`GET /query-result` 取持久化结果、`GET /inspect`（`type=plan`/`var`/`log`）按需查看 plan 代码、变量或日志。

## 1. 生成请求 ID

- **URL**：`GET /agent-cli/gen-request-id`
- **说明**：生成一次智能体会话的唯一 `requestId`。
- **请求参数**：无
- **响应体**：
  - `data`：`string`，生成的 `requestId`

---

## 2. 运行智能体

- **URL**：`POST /agent-cli/run`
- **说明**：根据请求参数**同步**启动智能体运行，返回时表示当次执行已结束（成功或失败）。
- **请求体**：`AgentRunRequest`（JSON）
  - `agentName`：`string`，**必填**；要运行的 Agent 名称
  - `requestId`：`string`，可选；外部指定的请求 ID，不传则由服务端生成（可先调用 `/gen-request-id` 获取）
  - `agentScript`：`string`，可选；若传入则与当前已加载的 Agent 脚本比对，不一致时会落盘并重新加载后再执行
  - `parameters`：`object`，可选；业务参数键值对（`Map<String, Object>`），会传入智能体上下文
- **响应体**：`AgentRunResponse`
  - `status`：`integer`，当次运行结果状态码（如 `100` 表示执行完成，`200` 表示已停止等，具体以实现为准）
  - `agentName`：`string`，实际运行的 Agent 名称
  - `requestId`：`string`，本次运行对应的请求 ID
  - `relatedUserId`：`string`，关联用户 ID（如有）
  - `agentResult`：`object`，智能体返回的业务结果
  - `agentInstances`：`AgentInstanceBrief[]`，当前 `requestId` 下的实例信息列表，用于搭配 `/inspect` 做精细检查

**AgentInstanceBrief 结构**：

- `agentId`：`long`，智能体实例 ID
- `agentName`：`string`，智能体实例名称

---

## 3. 重新运行智能体

- **URL**：`POST /agent-cli/rerun`
- **说明**：基于已有 `requestId` 和新的参数，对该会话当前入口实例进行重新运行（forceRerun）。
- **请求参数（Query）**：
  - `requestId`：`string`，必填，请求 ID
- **请求体**：`Map<String, Object>`（JSON），新的业务参数（与 `/run` 的 `parameters` 结构一致）
- **响应体**：`AgentRunResponse`，结构与 `/run` 相同；其中 `agentName` 可能为空字符串

---

## 4. 暂停智能体

- **URL**：`POST /agent-cli/suspend`
- **说明**：暂停指定 `requestId` 对应的智能体执行。
- **请求参数（Query）**：
  - `requestId`：`string`，必填
- **请求体**：无
- **响应体**：`Void`（`data` 为 `null`，仅表示成功/失败）

---

## 5. 停止智能体

- **URL**：`POST /agent-cli/stop`
- **说明**：停止指定 `requestId` 对应的智能体执行。
- **请求参数（Query）**：
  - `requestId`：`string`，必填
- **请求体**：无
- **响应体**：`Void`

---

## 6. 查询智能体状态

- **URL**：`GET /agent-cli/status`
- **说明**：查询指定 `requestId` 的当前运行状态。
- **请求参数（Query）**：
  - `requestId`：`string`，必填
- **响应体**：
  - `data`：`integer`，表示该 `requestId` 对应的**整次请求的全局状态码**（与入口 agent 的 `agentStatus` 一致，来源于 `AgentStatusManager`）。状态码定义在 agent-core 的 `TaskStatus` / `ITaskStatus` 中，常见取值示例（以实际常量为准）：
    - **运行中**：如 `1`、`100`
    - **挂起/暂停**：如 `3`、`302`（挂起完成-强制）等
    - **正常结束**：如 `500`（整体流程结束）
    - **异常结束**：如 `510`（执行失败）、已停止（对应常量 `STATUS_STOP`，具体数值见 agent-core）
  - 可根据 `data` 判断会话是否仍在运行、已结束或已失败，以便决定是否轮询结果或调用暂停/停止接口。

---

## 7. 查询智能体结果

- **URL**：`GET /agent-cli/query-result`
- **说明**：获取指定 `requestId` 的**已持久化**运行结果（从入口 agent 主表读取）。建议在智能体已结束（如 `/status` 返回 `500`）后再查询，否则可能为空或中间结果。
- **请求参数（Query）**：
  - `requestId`：`string`，必填
- **响应体**：
  - `data`：解析自存储的 `agentResult`，可能为 **JSON 对象**、**JSON 数组** 或 **空字符串**（结构取决于具体智能体输出）

---

## 8. 检查智能体运行结果（inspect）

- **URL**：`GET /agent-cli/inspect`
- **说明**：按 `type` 查询智能体的 plan 结果、变量、日志等；可按 `agentId`、`name` 等进行过滤。
- **请求参数（Query）**：
  - `requestId`：`string`，必填，会话请求 ID
  - `agentId`：`long`，选填，指定某个智能体实例 ID；不传时遍历该 `requestId` 下所有实例
  - `type`：`string`，必填，查询类型，取值含义如下：
    - **`plan`**：按 agent 中 plan 的 `name` 获取对应**完整的 plan 代码**（可与 `name` 配合指定 plan）。
    - **`var`**：获取 agent runtime instance 的**变量结果**。变量名本质也是 plan 的名字，但返回的是该 plan 的**执行结果**（变量值），而非 plan 代码本身；可与 `name` 配合按变量/plan 名过滤。
    - **`log`**：获取 agent runtime instance 的**日志信息**；可与 `name` 配合按 plan name 过滤。
  - `name`：`string`，选填，按名称过滤（plan 名/变量名等，具体含义见上述 `type`）
  - `levelWarnOnly`：`string`，选填，仅返回告警级别（如 `true`/`false` 或具体级别）
  - `pathOnly`：`string`，选填，仅返回路径等精简信息
- **响应体**：
  - `data`：`object`，与 `type` 及实现有关

---

## 9. 列出运行中的会话

- **URL**：`GET /agent-cli/status-running`
- **说明**：列出当前仍在运行中的会话 ID 列表。
- **请求参数**：无
- **响应体**：
  - `data`：`string[]`，正在运行的 `requestId` 列表

---

## 10. 检查智能体脚本

- **URL**：`POST /agent-cli/check`
- **说明**：校验智能体脚本是否可正常运行。
- **请求体**：`AgentCheckRequest`
  - `name`：`string`，智能体名称
  - `script`：`string`，智能体脚本内容
  - `checkTool`：`boolean`，是否检查智能体依赖的工具是否存在
- **响应体**：`AgentCheckResponse`
  - `success`：`boolean`，是否校验通过
  - `message`：`string`，提示信息或错误信息
  - `errors`：`object`，详细错误信息（结构由实现决定）

---

## 11. 上传 Agent

- **URL**：`POST /agent-cli/upload`
- **说明**：上传 Agent 脚本，按 agent 名字保存到 agent 目录（`agt_xxx.package` 或 `agt_xxx.number.package`）。
- **请求体**：`AgentUploadRequest`
  - `agentName`：`string`，Agent 全名，如 `agt_my_agent.demo` 或 `agt_my_agent.1.demo`
  - `script`：`string`，Agent 脚本内容
- **响应体**：`AgentUploadResponse`
  - `success`：`boolean`，是否上传成功
  - `message`：`string`，提示或错误信息
  - `agentName`：`string`，保存后的 Agent 全名
  - `savedPath`：`string`，保存的相对路径，如 `system/agt/demo/agt_my_agent.txt`

---

## 12. 下载 Agent

- **URL**：`GET /agent-cli/download`
- **说明**：下载指定 Agent，返回脚本内容。
- **请求参数（Query）**：
  - `agentName`：`string`，必填，Agent 名称
- **响应体**：`AgentDownloadResponse`
  - `success`：`boolean`，是否下载成功
  - `message`：`string`，提示或错误信息
  - `agentName`：`string`，Agent 全名
  - `script`：`string`，Agent 脚本内容

---

## 13. 调试 Agent

- **URL**：`POST /agent-cli/debug`
- **说明**：使用 `agt_agent_improve.template` 对指定 Agent 进行调试和改进，返回改进结果与日志。
- **请求体**：`AgentDebugRequest`
  - `agentName`：`string`，待调试的 Agent 全名
  - `requirement`：`string`，改进目标/用户需求（对应模板中的 `userInput`）
  - `agentScript`：`string`，可选；待调试的脚本内容，不传时从 `agentName` 对应的 Agent 读取
- **响应体**：`AgentDebugResponse`
  - `requestId`：`string`，请求 ID，用于追溯
  - `success`：`boolean`，是否调试/改进成功
  - `message`：`string`，提示或错误信息
  - `agentName`：`string`，改进后的 Agent 全名
  - `agentVersion`：`string`，改进后的 Agent 版本
  - `script`：`string`，改进后的脚本内容
  - `logLines`：`string[]`，错误或执行日志

---

## 14. 生成 Agent

- **URL**：`POST /agent-cli/gen`
- **说明**：使用 `agt_agent_gen.template` 根据需求生成新的 Agent，返回脚本与日志。
- **请求体**：`AgentGenRequest`
  - `agentName`：`string`，可选；期望的 Agent 名称（用于约束生成结果）
  - `requirement`：`string`，生成需求描述
- **响应体**：`AgentGenResponse`
  - `success`：`boolean`，是否生成成功
  - `message`：`string`，提示或错误信息
  - `agentName`：`string`，生成后的 Agent 名称
  - `script`：`string`，生成的脚本内容
  - `requestId`：`string`，请求 ID
  - `logLines`：`string[]`，错误或执行日志

---

## 15. 获取 AgentFlow 语法提示

- **URL**：`GET /agent-cli/grammar`
- **说明**：获取 AgentFlow 语法相关说明内容。
- **请求参数（Query）**：
  - `grammarType`：`string`，必填；可选值示例：
    - `basic`：基础语法
    - `evolution`：计划与进化语法
    - `fn`：函数说明
- **响应体**：`AgentGrammarResponse`
  - `success`：`boolean`，是否成功
  - `message`：`string`，提示信息
  - `grammarType`：`string`，返回的语法类型
  - `content`：`string`，语法提示内容
  - `requestId`：`string`，请求 ID
  - `logLines`：`string[]`，错误或执行日志

---

## 接口一览

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /agent-cli/gen-request-id | 生成请求 ID |
| POST | /agent-cli/run | 运行智能体（同步） |
| POST | /agent-cli/rerun | 重新运行智能体 |
| POST | /agent-cli/suspend | 暂停智能体 |
| POST | /agent-cli/stop | 停止智能体 |
| GET | /agent-cli/status | 查询智能体状态 |
| GET | /agent-cli/query-result | 查询智能体结果 |
| GET | /agent-cli/inspect | 检查运行结果（plan/var/log） |
| GET | /agent-cli/status-running | 列出运行中的会话 |
| POST | /agent-cli/check | 检查智能体脚本 |
| POST | /agent-cli/upload | 上传 Agent |
| GET | /agent-cli/download | 下载 Agent |
| POST | /agent-cli/debug | 调试/改进 Agent |
| POST | /agent-cli/gen | 生成 Agent |
| GET | /agent-cli/grammar | 获取 AgentFlow 语法提示 |

