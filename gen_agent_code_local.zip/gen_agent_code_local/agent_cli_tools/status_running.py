import requests
from config import config

def get_running_sessions():
    """列出当前仍在运行中的会话 ID 列表"""
    url = config.get_url("/status-running")
    
    response = requests.get(url, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()