import json
import os
import sys

import requests

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import KB_BASE_URL, config


def download_kb_file(file_name):
    """下载知识文件"""
    url = f"{KB_BASE_URL}?apiCode=kb_file_download&fileName={file_name}"
    print(url, config.get_headers())
    response = requests.post(
        url,
        
        headers=config.get_headers(),
    )

    if response.status_code == 200:
        content_type = response.headers.get("Content-Type", "")
        if "application/json" in content_type.lower():
            result = response.json()
            if result.get("code") == 200:
                return result.get("data")
            else:
                raise Exception(f"API Error: {result.get('msg')}")
        return response.content
    else:
        response.raise_for_status()


def main():
    file_name = "test_api_codex/test_matrix.json"
    if file_name:
        result = download_kb_file(file_name)
        if isinstance(result, (bytes, bytearray)):
            print(f"Downloaded {len(result)} bytes")
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
# http://172.18.2.14:5171/api/gw/run/api?apiCode=kb_file_download&fileName=test_api_codex/test_matrix.json {'Authorization': 'Bearer sk-YVuw5Dd-tOALhuweIAOfFRLkoQr_Dk66'}