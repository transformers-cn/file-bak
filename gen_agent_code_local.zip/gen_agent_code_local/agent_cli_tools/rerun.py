import requests
from config import config

def rerun_agent(request_id, parameters):
    """
    基于已有 requestId 和新的参数，对该会话当前入口实例进行重新运行
    
    Args:
        request_id: 请求 ID
        parameters: 新的业务参数
    """
    url = config.get_url("/rerun")
    params = {"requestId": request_id}
    
    response = requests.post(url, params=params, json=parameters, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()