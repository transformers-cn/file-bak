import requests
from config import config

def upload_agent(agent_name, script):
    """
    上传 Agent 脚本，按 agent 名字保存到 agent 目录
    
    Args:
        agent_name: Agent 全名，如 agt_my_agent.demo 或 agt_my_agent.1.demo
        script: Agent 脚本内容
    """
    url = config.get_url("/upload")
    
    payload = {
        "agentName": agent_name,
        "script": script,
        "personal": config.personal
    }
    print(payload)
    print(f"Uploading agent '{agent_name}' to {url}...")
    response = requests.post(url, json=payload, headers=config.get_headers())
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 200:
            data = result.get("data", {})
            if data.get("success") is False:
                raise Exception(f"Upload Error: {data.get('message', 'Unknown error')}")
            return data
        else:
            raise Exception(f"API Error: {result.get('message', 'Unknown error')}")
    else:
        response.raise_for_status()
