import requests
from config import config

def debug_agent(agent_name, requirement, agent_script=None):
    """
    使用 agt_agent_improve.template 对指定 Agent 进行调试和改进
    
    Args:
        agent_name: 待调试的 Agent 全名
        requirement: 改进目标/用户需求
        agent_script: 待调试的脚本内容，不传时从 agentName 对应的 Agent 读取
    """
    url = config.get_url("/debug")
    
    payload = {
        "agentName": agent_name,
        "requirement": requirement
    }
    
    if agent_script:
        payload["agentScript"] = agent_script
    
    response = requests.post(url, json=payload, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()