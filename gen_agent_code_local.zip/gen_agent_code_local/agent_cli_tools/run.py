import requests
from config import config

def run_agent(agent_name,request_id, parameters=None, file_map=None):
    """
    根据请求参数同步启动智能体运行
    
    Args:
        agent_name: 要运行的 Agent 名称
        parameters: 业务参数键值对，包含requestId、agentId等参数
        file_map: 文件映射，键为参数名，值为文件路径或文件对象
    """
    url = config.get_url("/run")
    
    # 构建URL参数
    params = {
        "agentName": agent_name,
        "requestId": request_id,
        "personal": config.personal,
        "createInstance":True
        
    }
    
    # 将parameters中的参数合并到URL参数中
    if parameters:
        params.update(parameters)
    
    print(f"请求参数: {params}")
    
    # 处理文件上传
    files = None
    if file_map:
        files = {}
        for key, file_path in file_map.items():
            if isinstance(file_path, str):
                # 如果是文件路径，打开文件
                files[key] = open(file_path, 'rb')
            else:
                # 如果是文件对象，直接使用
                files[key] = file_path
    
    try:
        response = requests.post(url, params=params, files=files, headers=config.get_headers())
        print(f"响应数据: {response.json()}")
        if response.status_code == 200:
            result = response.json()
            # 
            if result.get("code") == 200:
                return result.get("data")
            else:
                print(result)
                raise Exception(f"API Error: {result.get('msg')}")
        else:
            response.raise_for_status()
    finally:
        # 确保文件被关闭
        if files:
            for file_obj in files.values():
                if hasattr(file_obj, 'close'):
                    file_obj.close()
