import json
import os
import sys

import requests

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import KB_BASE_URL, config


def list_knowledge_by_path(full_path):
    """根据文件夹全路径查询知识列表"""
    url = f"{KB_BASE_URL}?apiCode=kbs_query_knowledges_by_path&fullPath={full_path}"
    print(url, config.get_headers())
    response = requests.post(url,  headers=config.get_headers())

    if response.status_code == 200:
        result = response.json()
        print(f"API Response: {json.dumps(result, ensure_ascii=False, indent=2)}")
        if result.get("code") == 200:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()


def main():
    full_path = "test_api_codex"
    if full_path:
        result = list_knowledge_by_path(full_path)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
