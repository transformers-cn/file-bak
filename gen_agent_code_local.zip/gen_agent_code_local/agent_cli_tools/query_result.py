import requests
from config import config

def query_agent_result(request_id):
    """获取指定 requestId 的已持久化运行结果"""
    url = config.get_url("/query-result")
    params = {"requestId": request_id}
    
    response = requests.get(url, params=params, headers=config.get_headers())
    print(url)
    print(response.json())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 200:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()