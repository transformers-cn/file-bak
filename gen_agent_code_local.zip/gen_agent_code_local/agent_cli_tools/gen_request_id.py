import requests
from config import config

def gen_request_id():
    """生成一次智能体会话的唯一 requestId"""
    url = config.get_url("/gen-request-id")

    response = requests.get(url, headers=config.get_headers())
    
    
    if response.status_code == 200:
        result = response.json()
        # print(result)
        if result.get("code") == 200:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()