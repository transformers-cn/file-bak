import requests
from config import config

def get_grammar(grammar_type):
    """
    获取 AgentFlow 语法相关说明内容
    
    Args:
        grammar_type: 语法类型 (basic/evolution/fn)
    """
    url = config.get_url("/grammar")
    params = {"grammarType": grammar_type}
    
    response = requests.get(url, params=params, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()