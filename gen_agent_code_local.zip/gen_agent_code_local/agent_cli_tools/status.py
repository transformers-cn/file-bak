import requests
from config import config

def get_agent_status(request_id):
    """查询指定 requestId 的当前运行状态"""
    url = config.get_url("/status")
    params = {"requestId": request_id}
    
    response = requests.post(url, params=params, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 200:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()