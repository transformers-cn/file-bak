import requests
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import config

def inspect_agent(request_id, inspect_type, agent_id=None, name=None, level_warn_only=True, logLevel='ERROR'):
    """
    按 type 查询智能体的 plan 结果、变量、日志等
    
    Args:
        request_id: 会话请求 ID
        inspect_type: 查询类型 (plan/var/log)
        agent_id: 指定某个智能体实例 ID
        name: 按名称过滤
        level_warn_only: 仅返回告警级别
        path_only: 仅返回路径等精简信息
    """
    url = config.get_url("/inspect")
    params = {
        "requestId": request_id,
        "type": inspect_type
    }
    
    if agent_id:
        params["agentId"] = agent_id
    if name:
        params["name"] = name
    if level_warn_only:
        params["levelWarnOnly"] = level_warn_only
    if logLevel:
        params["logLevel"] = logLevel
    
    response = requests.get(url, params=params, headers=config.get_headers())
    
    if response.status_code == 200:
        result = response.json()
        print(f"响应数据: {result}")
        if result.get("code") == 200:
            return result.get("data")
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()