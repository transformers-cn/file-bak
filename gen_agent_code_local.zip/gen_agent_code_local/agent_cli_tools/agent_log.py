import requests
from config import config

def get_agent_log(request_id, page_no=1, page_size=100, last_page=True):
    """
    获取指定 requestId 的 Agent 日志
    
    Args:
        request_id: 请求 ID
        page_no: 页码，默认为 1
        page_size: 每页大小，默认为 100
        last_page: 是否获取最后一页，默认为 True
    """
    url = config.get_url("/log")
    params = {
        "requestId": request_id,
        "pageNo": page_no,
        "pageSize": page_size,
        "lastPage": str(last_page).lower()
    }
    # print(params)
    response = requests.get(url, params=params, headers=config.get_headers())
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 200:
            logLlmTaskDetails = []
            for i in result['data'].get("logLlmTaskDetails", []):
                dc = {}
                dc["comment"] = i.get("comment")
                result = i.get("result",'')
                if len(result)>0 and result!='...':
                    dc["result"] = i.get("result")[:1000]+'...'
                else:
                    result = i.get("logLlmTaskSteps",[])
                    if len(result)>0:
                        dc["result"] = result[-1].get("output",'')[:300]+'...'
                    else:
                        dc["result"] = 'error'
                    
                logLlmTaskDetails.append(dc)
            print(f"接口响应: {logLlmTaskDetails}")
            return logLlmTaskDetails
        else:
            raise Exception(f"API Error: {result.get('msg')}")
    else:
        response.raise_for_status()