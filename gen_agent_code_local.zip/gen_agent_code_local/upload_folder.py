from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, List

from agent_cli_tools.check import check_agent_script
from agent_cli_tools.refresh_agent_store import refresh_agent_store
from agent_cli_tools.upload import upload_agent


DEFAULT_FOLDER_NAME = "test"
DEFAULT_PATTERN = "agt*.txt"
SCRIPT_PREFIX = "agt"
SCRIPT_SUFFIX = ".txt"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Upload agent scripts from a folder or a single file, then refresh the agent store."
    )

    parser.add_argument(
        "--folder_name",
        type=str,
        default=DEFAULT_FOLDER_NAME,
        help=f"Agent folder name under ./agent (default: {DEFAULT_FOLDER_NAME}).",
    )
    parser.add_argument(
        "--script_dir_path",
        type=str,
        default="",
        help="Optional: path to a directory containing agent scripts. "
        "If provided, it overrides agent/<folder_name> as the upload source.",
    )
    parser.add_argument(
        "--pattern",
        type=str,
        default=DEFAULT_PATTERN,
        help=f"Glob pattern to match scripts (default: {DEFAULT_PATTERN}).",
    )
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="If set, recursively scan subfolders under the upload directory.",
    )
    parser.add_argument(
        "--script_path",
        "--file_path",
        dest="script_path",
        type=str,
        default="",
        help="Optional: path to a single agent script. Supports absolute paths and relative paths "
        "such as agent\\ai_assist\\agt_main_executor.txt.",
    )
    parser.add_argument(
        "--no_refresh",
        action="store_true",
        help="Do not call /api/agent-store/refresh after uploading.",
    )

    return parser.parse_args()


def execute_step(step_name: str, func, *args, **kwargs) -> Any:
    """Execute a step and re-raise on failure."""
    try:
        result = func(*args, **kwargs)
        print(f"   OK: {step_name}")
        return result
    except Exception as exc:
        print(f"   FAIL: {step_name}: {exc}")
        raise


def resolve_existing_path(raw_path: str, project_root: Path) -> Path:
    """
    Resolve a path from either:
    - an absolute path
    - a path relative to the current working directory
    - a path relative to the project root
    """
    candidate = Path(raw_path).expanduser()

    if candidate.is_absolute():
        return candidate.resolve()

    cwd_candidate = (Path.cwd() / candidate).resolve()
    if cwd_candidate.exists():
        return cwd_candidate

    root_candidate = (project_root / candidate).resolve()
    if root_candidate.exists():
        return root_candidate

    return root_candidate


def infer_folder_name_from_path(path: Path) -> str | None:
    """
    Infer the folder name from a path like .../agent/<folder>/...
    Returns None if the path does not include an `agent` segment.
    """
    try:
        agent_index = path.parts.index("agent")
        return path.parts[agent_index + 1]
    except (ValueError, IndexError):
        return None


def load_text(file_path: Path) -> str:
    with file_path.open("r", encoding="utf-8") as f:
        return f.read()


def is_valid_agent_script_file(file_path: Path) -> bool:
    return (
        file_path.is_file()
        and file_path.name.startswith(SCRIPT_PREFIX)
        and file_path.name.endswith(SCRIPT_SUFFIX)
    )


def main() -> int:
    args = parse_args()
    project_root = Path(__file__).resolve().parent

    if args.script_path:
        script_file = resolve_existing_path(args.script_path, project_root)
        if not script_file.exists():
            raise FileNotFoundError(f"--script_path not found: {script_file}")
        if not is_valid_agent_script_file(script_file):
            raise ValueError(
                f"Invalid script file (must start with '{SCRIPT_PREFIX}' and end with '{SCRIPT_SUFFIX}'): {script_file}"
            )
        folder_name = infer_folder_name_from_path(script_file) or args.folder_name
        script_files: List[Path] = [script_file]
    else:
        if args.script_dir_path:
            dir_path = resolve_existing_path(args.script_dir_path, project_root)
        else:
            dir_path = (project_root / "agent" / args.folder_name).resolve()

        if not dir_path.exists() or not dir_path.is_dir():
            raise NotADirectoryError(f"Upload directory not found: {dir_path}")

        folder_name = infer_folder_name_from_path(dir_path) or args.folder_name
        iterator = dir_path.rglob(args.pattern) if args.recursive else dir_path.glob(args.pattern)
        script_files = sorted(p for p in iterator if is_valid_agent_script_file(p))

    if not script_files:
        print("No agent scripts found. Exit.")
        return 0

    print(f"Found {len(script_files)} script(s) to upload (folder: {folder_name})")

    agent_name_list: List[str] = []
    for i, script_file in enumerate(script_files, start=1):
        file_name = script_file.stem
        agent_name = f"{file_name}.{folder_name}"

        print("-" * 60)
        print(f"[{i}/{len(script_files)}] Agent: {agent_name}")

        print("1. Loading agent script...")
        sample_script = load_text(script_file)
        print("   OK: loaded")
        print(f"   Length: {len(sample_script)} chars")

        print("2. Checking agent script...")
        check_result = execute_step(
            "check agent script",
            check_agent_script,
            agent_name,
            sample_script,
        )
        print(f"   Check result: {check_result}")

        print("3. Uploading agent script...")
        upload_result = execute_step(
            "upload agent script",
            upload_agent,
            agent_name,
            sample_script,
        )
        print(f"   Upload result: {upload_result}")

        agent_name_list.append(agent_name)

    if args.no_refresh:
        print("Skip refresh because --no_refresh is set.")
        return 0

    print("-" * 60)
    print("4. Refreshing agent store...")
    execute_step("refresh agent store", refresh_agent_store, agent_name_list)
    print(f"Refresh finished for: {agent_name_list}")
    print("=== Done ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
    # python .\upload_folder.py --folder_name test
    # python .\upload_folder.py --script_path C:\Users\ahrli\Documents\trae_projects\gen_agent_code\agent\ai_assist\agt_main_executor.txt
    # python .\upload_folder.py --script_path agent\ai_assist\agt_main_executor.txt
