from agent_cli_tools.gen_request_id import gen_request_id
from agent_cli_tools.run import run_agent
from agent_cli_tools.check import check_agent_script
from agent_cli_tools.upload import upload_agent
from agent_cli_tools.agent_log import get_agent_log
from agent_cli_tools.inspect import inspect_agent
from agent_cli_tools.status import get_agent_status
from typing import Dict, Any
import json
from pprint import pprint
import time


def execute_step(step_name: str, func, *args, **kwargs) -> Any:
    """执行步骤并处理错误"""
    try:
        result = func(*args, **kwargs)
        print(f"   ✓ {step_name} 成功")
        return result
    except Exception as e:
        print(f"   ✗ {step_name} 失败: {e}")
        raise

def main(folder_name: str, file_name: str, run_parameters: Dict[str, Any]) -> int:
    """主执行函数
    
    Args:
        folder_name: Agent 文件夹名
        file_name: Agent 文件名
        run_parameters: 运行参数
        
    Returns:
        执行状态码，0表示成功，1表示失败
    """
    print("=== Agent 执行流程开始 ===")
    
    # 构建配置
    agent_name = f"{file_name}.{folder_name}"
    script_path = f"agent/{folder_name}/{file_name}.txt"
    
    try:
        # 1. 加载脚本
        print("1. 加载 Agent 脚本...")
        try:
            with open(script_path, "r", encoding="utf-8") as f:
                sample_script = f.read()
            print(f"   ✓ 加载脚本成功")
            print(f"   脚本长度: {len(sample_script)} 字符")
        except FileNotFoundError:
            print(f"   ✗ 脚本文件 {script_path} 不存在")
            raise
        except Exception as e:
            print(f"   ✗ 读取脚本文件失败 - {e}")
            raise
        
        # 2. 检查脚本
        print("2. 检查 Agent 脚本...")
        check_result = execute_step("检查脚本", check_agent_script, agent_name, sample_script)
        print(f"   检查结果: {check_result}")
        
        # 3. 上传脚本
        print("3. 上传 Agent 脚本...")
        upload_result = execute_step("上传脚本", upload_agent, agent_name, sample_script)
        print(f"   上传结果: {upload_result}")
        
        # 4. 生成请求 ID
        print("4. 生成请求 ID...")
        request_id = execute_step("生成请求ID", gen_request_id)
        print(f"   请求ID: {request_id}")
        
        # 5. 运行 Agent
        print("-" * 50)
        print("5. 运行 Agent...")
        try:
            run_result = execute_step(
                "运行Agent", 
                run_agent,
                agent_name=agent_name,
                request_id=request_id,
                parameters=run_parameters
            )
            print(f"   运行状态: {run_result}")
            print("-" * 50)
        except Exception as e:
            print(f"   运行失败: {e}")
            raise e
        while True:
            result = execute_step("获取执行结果", get_agent_status, request_id)
            print(f"   当前状态: {result}")
            if result==500 or result==510 or result==311:
                break
            time.sleep(5)
        
        # 6. 获取执行结果
        print("6. 获取 Agent 执行结果...")
        result = execute_step("获取执行结果", get_agent_log, request_id)
        if result :
            print("   Agent 执行详情:")
            pprint(result)
        print("7. 获取 Agent 执行结果...")
        result = execute_step("获取执行结果", inspect_agent, request_id,"log")

        if result :
            print("   Agent 执行详情:")
            pprint(result)
        else:
            print("   未找到执行详情")
        
        print("=== Agent 执行流程完成 ===")
        
    except Exception as e:
        print(f"\n❌ Agent 执行流程失败: {e}")
        print("=== Agent 执行流程中断 ===")
        return 1
    
    return 0

if __name__ == "__main__":
    # 示例：如何使用 main 函数
    # 实际使用时，应该在单独的配置文件中导入并调用
    print("=== 示例用法 ===")
    print("在单独的配置文件中，可以这样使用：")
    print("\nfrom run_agent import main")
    print("import json")
    print("\n# 配置参数")
    print("folder_name = 'pmap'")
    print("file_name = 'agt_selenium_codegen'")
    print("\n# 运行参数")
    print("run_parameters = {")
    print("    'current_step': '填写表单',")
    print("    'envinfo': json.dumps({")
    print("        'ui_states': [],")
    print("        'constraints': {'ui_only': False, 'data_validation': True},")
    print("        'required_elements': {")
    print("            'fields': [")
    print("                {")
    print("                    'name': 'username', 'type': 'text', 'required': True,")
    print("                    'element_id': 'id_611284575', 'label_text': 'Username',")
    print("                    'validation': 'not_empty'")
    print("                },")
    print("                {")
    print("                    'name': 'password', 'type': 'password', 'required': True,")
    print("                    'element_id': 'id_2354094910', 'label_text': 'Password',")
    print("                    'validation': 'not_empty'")
    print("                }")
    print("            ]")
    print("        }")
    print("    })")
    print("}")
    print("\n# 执行")
    print("main(folder_name, file_name, run_parameters)")
    print("================")