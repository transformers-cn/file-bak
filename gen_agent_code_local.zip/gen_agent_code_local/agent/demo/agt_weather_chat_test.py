from pathlib import Path
import sys

# Ensure project root is importable when executing from agent subfolder.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from run_agent_main import main


folder_name = "demo"
file_name = "agt_weather_chat"

run_parameters = {
    "userInput": "深圳天气怎么样"
}

print("=== 测试 Agent 执行：agt_weather_chat ===")
status = main(folder_name, file_name, run_parameters)
print(f"=== 执行完成，状态码: {status} ===")

assert status == 0, "Agent 执行失败，请检查脚本语法、参数和日志"
