---
name: agentflow-test-workflow
description: Enforce a test-first validation workflow after each AgentFlow script is created. Generate every per-agent Python test file strictly from the Recommended Test Template, then run it through the project runner and use the remaining skill guidance only to explain status, logs, validation results, and fixes.
---

# AgentFlow Test Workflow

## Purpose
After creating any AgentFlow script, always create and execute a Python test file, validate run results, and generate actionable fix suggestions when validation fails. Keep test-file generation strictly separated from runtime interpretation: the Recommended Test Template controls the Python source, while all other sections control execution and the explanatory report.

## Project Standard Entry Points
- Runner: `run_agent_main.py`
- Per-agent test file: `<agent_file_name>_test.py` (same folder as target agent)

## Mandatory Workflow
1. Confirm target agent location:
   - `folder_name` (e.g. `pmap`)
   - `file_name` (e.g. `agt_selenium_codegen`)
2. Create a dedicated test file for this agent in the same folder as the agent script.
   - Required path rule:
     - agent script: `agent/<folder_name>/<file_name>.txt`
     - test script: `agent/<folder_name>/<file_name>_test.py`
3. Copy the complete Recommended Test Template into the test file.
4. Replace only the template placeholders and the contents of the `run_parameters` dictionary with realistic input that follows the target agent parameter contract.
5. Do not add, remove, reorder, or rewrite any other Python statement from the template.
6. Execute the test file with the required UTF-8 command.
7. Collect the status code and runtime logs produced by the execution.
8. Apply the remaining sections of this skill to explain the observed result outside the Python test file.
9. If failed, generate fix suggestions grouped by root cause.

Do not skip test creation or execution.

## Source Template Boundary and Precedence (Required)
- Treat the code block under **Recommended Test Template** as the only allowed source structure for every generated `<file_name>_test.py`.
- Make only these substitutions:
  1. Replace `"<folder>"` with the actual agent folder name.
  2. Replace `"<agent_file_without_txt>"` with the actual agent filename without `.txt`.
  3. Replace the example entries inside `run_parameters` with the exact parameters and realistic values required by the target agent.
- Preserve every other template line, import, comment, blank-line grouping, statement order, print statement, `main(...)` call, and final assertion.
- Do not add helper functions, classes, polling loops, `try/except`, status-code branching, log retrieval, result-schema assertions, syntax checks, upload logic, command-line parsing, or any other Python code.
- Do not convert guidance from Runtime Status Codes, Validation Checklist, Log-to-Code Mapping, Failure Diagnosis, Multi-Agent Batch Mode, or Guardrails into Python.
- Use every section outside **Recommended Test Template** only to:
  - choose valid placeholder and parameter values,
  - run the generated test,
  - inspect information produced by the run,
  - explain and classify the result in the response or test report,
  - recommend fixes.
- If any other instruction appears to conflict with the template, the template wins for generated Python source. Record and explain the conflict in the report instead of changing the test code.

### Runtime Encoding Precheck (Required)
- Before running any per-agent Python test on Windows/PowerShell, enforce UTF-8 console output:
  - `$env:PYTHONIOENCODING='utf-8'; python "agent/<folder_name>/<file_name>_test.py"`
- Rationale: prevent GBK/console encoding crashes when logs contain symbols (e.g. ✓ ✗ ❌) or non-ASCII text.
- If this precheck is skipped and an encoding exception occurs, classify it as **environment/setup failure**, rerun with UTF-8 first, then continue diagnosis.

## run_parameters Construction Rule (Required)
- Modify only the entries inside the template's `run_parameters` dictionary.
- Parameter names in Python test `run_parameters` must strictly follow the target agent `parameter` definition in `agent/<folder>/<file>.txt`.
- Do not invent generic keys (for example `userInput`) when the agent already defines concrete parameter names.
- Default value type should be **string** for each parameter, unless the `parameter` definition explicitly states another type or business constraint.
- If a complex structure (object/array) is required by business context but parameter type is not explicitly defined, pass it as a JSON string.
- Before running test, cross-check:
  - every required agent parameter is provided,
  - no undefined extra parameter is included,
  - value type matches the intended parameter contract.

## Runtime Status Codes
Use the project runtime status codes from `docs/运行日志状态码.md` when judging whether a test truly passed or failed.

| 状态码 | 含义 | 测试判定 |
|---|---|---|
| `10` | `STATUS_PENDING`，待处理 | 仍在排队，不可判定完成 |
| `100` | `STATUS_RUNNING`，运行中 | 仍在执行中，需要继续等待 |
| `300` | `STATUS_SUSPEND`，挂起 | 按挂起类状态处理，检查是否为人工/RPA/等待类节点 |
| `301` | `STATUS_SUSPENDING_BY_FORCE`，强制挂起中 | 挂起流程处理中 |
| `302` | `STATUS_SUSPENDED_BY_FORCE`，强制挂起完成 | 已挂起，通常需要人工介入 |
| `305` | `STATUS_SUSPENDED_BY_THREAD`，子线程等待挂起 | 子线程等待导致暂停 |
| `309` | `STATUS_SUSPENDED_BY_AGENT`，Agent 切换挂起 | Agent 切换导致暂停 |
| `310` | `STATUS_SUSPENDED_BY_AUTO`，自动切人工挂起 | 模式切换导致暂停 |
| `311` | `STATUS_EXCEPTION_EXIT`，异常退出 | 运行失败，优先看异常栈和关键日志 |
| `312` | `STATUS_TIMEOUT_EXIT`，超时退出 | 运行失败，优先看超时和阻塞点 |
| `500` | `STATUS_STOP`，整体流程结束 | 表示流程结束，不等同于接口错误；继续检查结果和日志是否符合预期 |
| `510` | `STATUS_FAILED`，获得失败结果 | 业务失败，按失败处理并给出修复建议 |

Additional guidance:
- `run_agent` 返回的 HTTP `code == 200` 只表示请求被服务端接收，不代表 Agent 已经成功完成。
- 如果运行结果 `data.status == 100`，测试应继续等待而不是直接判失败。
- 如果 `data.status == 500`，优先把它视为“流程已结束”，再结合 `agentResult` 和日志判断是否符合预期。
- 如果 `data.status == 510`、`311` 或 `312`，直接进入失败诊断。
- 对于 `300-310` 的挂起类状态，先确认是否是设计预期；如果不是预期挂起，检查节点配置、人工步骤和切换逻辑。

## Test File Rules
- File naming:
  - required: `<file_name>_test.py`
  - example: `agt_selenium_codegen_test.py`
- File location (mandatory):
  - test file must be created in the same directory as the target agent `.txt` file
  - do not place per-agent test files in project root
- Source content (mandatory):
  - copy the full Recommended Test Template
  - apply only the substitutions allowed by Source Template Boundary and Precedence
  - do not produce an abbreviated, extended, refactored, or semantically equivalent variant
  - verify the completed file against the template before execution

## Recommended Test Template
This template is mandatory. “Recommended” is the retained section name, not permission to use an alternative.

```python
from pathlib import Path
import sys

# Add project root to sys.path when running from agent/<folder>/
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from run_agent_main import main
import json

folder_name = "<folder>"
file_name = "<agent_file_without_txt>"

run_parameters = {
    "userInput": "测试输入"
}

print("=== 测试 Agent 执行 ===")
status = main(folder_name, file_name, run_parameters)
print(f"=== 执行完成，状态码: {status} ===")

assert status == 0, "Agent 执行失败，请检查脚本语法、参数和日志"
```

## Validation Checklist
Apply this checklist after execution and present its findings in the explanatory report. Do not implement checklist items as additional Python code in the generated test file.

- Syntax path:
  - `check_agent_script` passed
  - upload passed
- Runtime path:
  - run request created successfully
  - run finished, or the returned status code is a terminal state that can be explained by the workflow
- Result path:
  - execution status code is terminal and acceptable for the scenario, typically `500` for flow stop or `0` for local wrapper success
  - key output fields/behavior meet expectation
- Log path:
  - logs belong to current request
  - no fatal exception in key task details
- Environment path:
  - test command uses UTF-8 output mode in Windows PowerShell (`$env:PYTHONIOENCODING='utf-8'; python ...`)

## Log-to-Code Mapping Rule (Required)
Perform this mapping in the post-run explanatory report only. Do not add log-fetching or mapping code to the generated Python test file.

In this project, `run_agent_main.py` reads logs via:
- `get_agent_log(request_id)` (see step 6 output around lines 82-87)

`logLlmTaskDetails` should be treated as a `list` array.  
For an agent that contains annotated steps (with `//` comments), map each log item to the nearest comment block and code line range.

Example mapping idea:
- Agent code:
  - `agent/pmap/agt_selenium_codegen.txt`
  - includes commented blocks like:
    - `// 读取必传入参 current_step`
    - `// 读取可选入参 envinfo`
  - followed by executable lines:
    - `assign('step_text', '{{current_step}}')`
    - `assign('env_text', '{{envinfo}}')`
- Runtime log:
  - if `logLlmTaskDetails` has 2 dict items, interpret as 2 executed blocks
  - align each dict item with one `//` comment section, then verify:
    - expected input variable was read,
    - expected assignment happened,
    - output/value in log is consistent with that section intent.

This mapping must be included in test analysis.  
If mapping is ambiguous, return `WARN` and ask for finer-grained comments/log markers.

## Failure Diagnosis and Fix Suggestions
When test fails, output findings with this structure outside the generated Python test file:

```markdown
## 测试失败分析
- 失败阶段: <语法检查/上传/运行/结果校验/日志校验>
- 现象: <错误信息或状态>
- 可能根因:
  1. <根因A>
  2. <根因B>
- 修改建议:
  1. <具体改法，指向 agent 代码块>
  2. <参数或模板修正建议>
  3. <日志补充建议，如增加关键 log(...)>
```

Prioritize:
1) blocking syntax/tool reference issues,
2) run parameter mismatch,
3) result schema mismatch,
4) insufficient logging,
5) log-to-comment mapping mismatch (comment intent vs actual execution result).

When diagnosing runtime failures, classify by status code first:
- `311` / `312`: runtime exception or timeout
- `510`: explicit business failure
- `300-310`: suspended state, determine whether expected
- `500`: flow finished, so investigate result/log mismatch rather than assuming transport failure

## Multi-Agent Batch Mode
If multiple agents are generated in one task:
- create one test file per agent (`<agent>_test.py`) in each agent's own folder, with every file strictly copied from the same Recommended Test Template
- execute sequentially
- produce a summary table:
  - agent
  - test file
  - pass/fail
  - top fix suggestion

## Guardrails
- Keep `agent_name` consistent across check/upload/run.
- Never use unrelated hard-coded log ids for current test.
- Keep test parameters close to real business inputs.
- If expected output is structured JSON, verify and explain required fields in the post-run report; do not add assertions beyond the template's existing final assertion.

## When To Apply This Skill
Apply when user asks to:
- create AgentFlow and verify correctness immediately,
- add a standardized agent test process,
- run post-generation checks and propose fixes automatically.
