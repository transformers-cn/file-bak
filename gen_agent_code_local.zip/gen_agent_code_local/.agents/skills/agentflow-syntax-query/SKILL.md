---
name: agentflow-syntax-query
description: Translate a user's natural-language question into the corresponding AgentFlow `agt*.txt` code or syntax snippet. Use when the user asks for AgentFlow syntax lookup, asks "how do I write this as an agent", or wants code generated directly from a requirement.
---

# AgentFlow Syntax Query

## Goal
Turn a user's question into the most direct AgentFlow code answer.

## Workflow
1. Identify the requested artifact: full `agt*.txt`, a minimal snippet, or a correction to existing code.
2. Map the request to the smallest valid AgentFlow structure that satisfies it.
3. Follow the project conventions used by `agentflow-codegen`:
   - metadata block in `/*{...}*/`
   - `agt*.txt` filename convention
   - `assign(...)`, `define('tpl_...')`, `n_...` plan flow
   - `{{var}}` placeholders only
   - keep executable lines commented above when emitting full files
4. Prefer code over explanation. If the user asks for "syntax" or "对应代码", return the code directly.
5. If the requirement is incomplete, choose safe defaults and keep the output minimal.

## Output Rules
- Output AgentFlow code first, not prose.
- If the user wants a full agent file, emit a complete `agt*.txt` body.
- If the user only asks about one construct, emit only the relevant snippet.
- When the request is about chat-style agents, include `{{fn.chatFlag(...)}}` only when needed.
- When the request is about validation or execution, include the relevant `vrf_`, `psr_`, or `act_` chain rather than describing it.

## Priority
1. Correct AgentFlow syntax
2. Minimal valid code
3. Match the user's exact intent

