---
name: prompt-generator
description: Generate ready-to-use prompts from rough requirements, including system prompts, developer prompts, user prompts, extraction prompts, classification prompts, transformation prompts, workflow prompts, and agent instructions. Use when the user asks to write a prompt or prompt template, turn a task brief into a reusable prompt, package a prompt for an LLM workflow, or draft Chinese or English prompts with explicit input, output, and guardrail requirements.
---

# Prompt Generator

## Goal

Turn a rough brief into a prompt that can be pasted into an LLM without extra rewriting.

## Workflow

1. Identify the target prompt type: system, developer, user, extraction, classification, transformation, workflow, or agent prompt.
2. Extract hard constraints, optional preferences, input shape, output shape, tone, audience, examples, and failure handling.
3. Preserve domain terms, field names, policy wording, and any text the user marked as mandatory.
4. Prefer explicit sections: Role, Goal, Inputs, Requirements, If information is missing, Output, Quality bar.
5. Make the prompt deterministic when downstream code or review depends on the result.
6. Keep the prompt as short as possible while still removing ambiguity.
7. If key details are missing and would change the prompt materially, ask up to 3 targeted questions; otherwise make safe assumptions and say so briefly.

## Output Rules

- Output the final prompt first.
- If helpful, add a short note with assumptions or a one-line rationale after the prompt.
- Do not expand into long explanations unless the user asks.
- For structured outputs, define the schema, allowed values, and fallback values.
- For generation tasks, define audience, tone, must-cover points, banned content, and length limits.
- For agent prompts, include tool boundaries, stop conditions, validation steps, and escalation rules.
- Write natural Chinese when the user speaks Chinese unless they prefer English.

## Prompt Skeleton

```text
You are [role].

Goal:
[one-sentence objective]

Inputs:
[what the model will receive]

Requirements:
- [hard constraint]
- [hard constraint]

If information is missing:
[fallback behavior]

Output:
[format, schema, or section list]

Quality bar:
- [what a good answer must include]
- [what to avoid]
```

## Quick Checks

- Remove vague words like "better", "appropriate", or "nice" unless the prompt defines them.
- Keep placeholders explicit, such as `[task]`, `{{input}}`, or JSON field names.
- Avoid mixing strategy, context, and output rules in one paragraph.
- If the prompt will be reused, make it easy to edit and test.
