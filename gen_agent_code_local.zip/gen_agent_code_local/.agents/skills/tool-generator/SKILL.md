---
name: tool-generator
description: Generate reusable tools from requirements, including API wrappers, CLI entry points, input validation, error handling, and test scaffolds. Use when the user asks to create a new tool, add tool scripts, wrap HTTP endpoints, or standardize tool implementation patterns.
---

# Tool Generator

## Purpose

将自然语言需求转为可运行、可复用的工具实现，默认产出：
- 核心函数（可被其他模块调用）
- 命令行入口（可直接执行）
- 参数与错误处理
- 最小可运行测试或验证步骤

## When To Use

在以下场景自动应用：
- 用户要求“新增一个工具文件/脚本”
- 用户提供 API 示例（如 `fetch`/curl）要求转 Python/Node 工具
- 用户要求统一工具风格、复用模板、补齐校验逻辑
- 用户要求可执行示例与快速验证命令

## Discovery Checklist

开始实现前，先确认以下信息（若缺失，按默认值执行并在结果中声明）：
- 工具类型：`http-client` / `file-processor` / `automation` / `wrapper`
- 目标语言与运行方式：如 Python + `python xxx.py`
- 输入参数：必填项、可选项、默认值
- 认证方式：Bearer/API Key/Cookie/无
- 返回结果要求：原样透传 / 标准化结构 / 仅打印关键字段
- 失败策略：抛异常 / 返回错误对象 / 重试

## Implementation Workflow

1. **定义接口**
   - 先定义一个可复用函数：`do_<tool_action>(...)`
   - 参数显式化，避免隐藏依赖

2. **实现核心逻辑**
   - 输入校验（类型、空值、边界）
   - 远程调用或业务处理
   - 统一异常信息（可定位、可诊断）

3. **增加可执行入口**
   - 提供 `main()` 与 `if __name__ == "__main__":`
   - 默认参数可直接跑通一次最小流程

4. **补充可维护性**
   - 必要注释只解释“为什么”
   - 敏感信息支持环境变量覆盖
   - 输出结构清晰，便于日志检索

5. **验证**
   - 至少提供一个本地执行命令
   - 如可行，补充基础测试脚手架或断言示例

## Output Contract

每次生成工具后，输出应包含：
- 变更文件路径
- 关键函数名与用途
- 运行命令
- 环境变量说明（若有）
- 已知限制与后续建议

## Python Template

```python
import os
from typing import Any, Dict, Optional


def do_action(required_arg: str, optional_arg: Optional[str] = None) -> Dict[str, Any]:
    if not required_arg:
        raise ValueError("required_arg is required")

    token = os.getenv("TOOL_TOKEN", "")
    # core logic here
    result = {"ok": True, "data": {"required_arg": required_arg, "optional_arg": optional_arg, "token_set": bool(token)}}
    return result


def main() -> None:
    result = do_action(required_arg="demo", optional_arg=None)
    print(result)


if __name__ == "__main__":
    main()
```

## HTTP Wrapper Rules

- 默认超时：`timeout=30~60s`
- 请求体优先使用结构化对象，再决定 `json=` 或 `data=`
- 返回值优先尝试 JSON 解析，失败时保留原始文本用于诊断
- 对非 2xx 响应抛出明确异常，包含状态码与关键错误信息

## Naming Conventions

- 文件名：`<action>_<target>.py`（如 `refresh_agent_store.py`）
- 函数名：`verb_noun`（如 `refresh_agent_store`）
- 环境变量：全大写、带业务前缀（如 `AGENT_STORE_TOKEN`）

## Do / Don't

- Do：优先复用项目已有配置与请求封装
- Do：把“硬编码敏感值”改为“默认值 + 环境变量覆盖”
- Do：返回值结构尽量稳定，便于上层调用
- Don't：把业务常量散落在多个函数中
- Don't：吞异常不报错上下文
- Don't：只写脚本不留可复用函数

