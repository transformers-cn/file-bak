---
name: agentflow-validation
description: Validate AgentFlow scripts across syntax, execution, output correctness, and runtime logs using a staged acceptance workflow. Use when user asks to check whether an agt script is correct, runnable, and reliable, or asks for run verification and log auditing.
---

# AgentFlow Validation

## Purpose
Provide a standard acceptance workflow for AgentFlow scripts:
1) grammar/syntax correctness,
2) runtime execution success,
3) result correctness,
4) log completeness and quality.

## Inputs
- `agent_name`: target agent name.
- `agent_script`: generated or modified script text.
- `test_cases`: list of run parameters and expected assertions.
- Optional: `timeout_seconds`, `poll_interval_seconds`.

## Validation Stages

### Stage 1: Preflight
- Ensure `agent_name` and `agent_script` are not empty.
- Ensure at least one test case exists.
- Check script has metadata block `/*{...}*/`.
- Check script contains at least one output plan named `n_xxx`.

If any check fails, stop and return `BLOCKER`.

### Stage 2: Static Syntax and Reference Check
- Run:
  - `check_agent_script(agent_name, agent_script)`
- Mark `BLOCKER` if:
  - DSL parse errors exist.
  - `define/tpl` references are missing.
  - invalid plan jump target is detected.
- Mark `WARN` if:
  - output format contract is ambiguous (no explicit JSON/markdown requirement).
  - key typed values likely treated as strings (recommend `fn.raw`).

### Stage 3: Upload and Execution Check
- Upload script:
  - `upload_agent(agent_name, agent_script)`
- Create `request_id` and run one test case:
  - `gen_request_id()`
  - `run_agent(agent_name, request_id, parameters)`
- Poll status:
  - `get_agent_status(request_id)` until `SUCCESS/FAILED/TIMEOUT`.

Rules:
- `FAILED` or timeout => `BLOCKER`.
- Keep full status timeline in report.

### Stage 4: Result Correctness Check
- Query run result:
  - `query_agent_result(request_id)`
- Validate assertions from test case:
  - non-empty response,
  - required fields exist,
  - value type/range checks,
  - business-rule checks.

Scoring:
- Any required assertion failure => `FAIL`.
- Optional assertion failure => `WARN`.

### Stage 5: Runtime Log Audit
- Query logs for the same `request_id` (never use hard-coded IDs).
- Audit dimensions:
  - key node coverage (start/decision/output/error),
  - exception markers and stack traces,
  - variable traceability for critical context.

Mark:
- Missing key logs => `WARN`.
- Contradictory logs or fatal exceptions => `FAIL`.

### Stage 6: Final Verdict and Report
- Aggregate all stage results into one structured report.
- Final verdict:
  - `PASS`: no blocker/fail.
  - `PARTIAL_PASS`: no blocker, but warnings exist.
  - `FAIL`: any blocker/fail exists.

## Severity Definition
- `BLOCKER`: cannot continue validation (syntax error, upload/run failure, timeout).
- `FAIL`: validation completed but correctness/log criteria not met.
- `WARN`: runs and returns results, but quality risks remain.
- `INFO`: observations without risk impact.

## Output Template
Use this markdown template:

```markdown
# AgentFlow Validation Report

## Target
- agent_name: <name>
- request_id: <id>

## Stage Results
- Preflight: PASS/FAIL
- Static Check: PASS/WARN/FAIL
- Execution Check: PASS/FAIL
- Result Check: PASS/WARN/FAIL
- Log Audit: PASS/WARN/FAIL

## Findings
- [SEVERITY] <finding>
- [SEVERITY] <finding>

## Evidence
- check_agent_script: <summary>
- status_timeline: <timeline>
- result_snapshot: <summary>
- log_snapshot: <summary>

## Final Verdict
PASS / PARTIAL_PASS / FAIL

## Next Actions
1. <highest-priority fix>
2. <second-priority fix>
```

## Implementation Notes (Python Flow)
Use these functions as canonical execution flow:
- `gen_request_id`
- `check_agent_script`
- `upload_agent`
- `run_agent`
- `get_agent_status`
- `query_agent_result`
- `get_agent_log` (must be imported and keyed by current `request_id`)

## Guardrails
- Do not skip static check before run.
- Do not query logs with unrelated hard-coded run IDs.
- Keep upload/check/run on the same `agent_name`.
- Use retry polling with timeout; do not sleep once and assume completion.

## Suggested Test Case Format
```json
[
  {
    "name": "smoke",
    "parameters": {"userInput": "测试参数"},
    "assertions": {
      "required_fields": ["result"],
      "type_checks": {"result": "string"},
      "contains": {"result": ["关键字A"]}
    }
  }
]
```

## When To Apply This Skill
Apply this skill when user asks to:
- verify AgentFlow code quality after generation,
- confirm script can run successfully,
- check run results against expectations,
- audit runtime logs and diagnose run failures.
