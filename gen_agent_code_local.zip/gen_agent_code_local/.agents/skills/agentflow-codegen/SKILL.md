---
name: agentflow-codegen
description: Generate production-ready AgentFlow scripts from requirements using the project grammar and conventions, including plan chains, chat prompts, act_plan, act_rpg, act_kb, act_artifact, act_python, and multi-turn execution/debugging flows. Use when creating or modifying agt*.txt agents, writing define/tpl prompts, adding act_* tool calls, building task or RPG flows, or debugging AgentFlow syntax and execution flow.
---

# AgentFlow Code Generation

## Purpose
Turn user requirements into executable AgentFlow code that follows this project grammar and file conventions.

## Output Rules
- File name must start with `agt` and end with `.txt`.
- Keep agent metadata in top block comment `/*{...}*/`.
- Always provide at least one executable plan chain.
- If using chat mode, end prompt template with `{{fn.chatFlag(...)}}`.
- Use `{{var}}` in templates; do not use bare variable names.
- Every generated AgentFlow code line must have a comment line immediately above it.
- For chat-style agents, default to this annotation convention:
  - `//#` for a top-level section title rendered as Markdown H1.
  - `//##` for a subsection title rendered as Markdown H2.
  - `//$ 变量名` to display the current value of a variable in the chat UI.
  - Keep a space after the marker, for example `//# 天气查询 Chat Demo`.
- For non-chat explanatory comments, continue using ordinary `//` comments as needed, but do not leave executable lines without a comment above them.
- `define('tpl_xxx', ...)` is optional and must be added only when referenced by an executable plan chain.
- Do not keep unused templates or other unreachable blocks in final output.

## Required File Skeleton
```text
/*{
  "title": "Agent Title",
  "parameter": [
    {"name":"userInput","label":"需求","required":true}
  ],
  "version": 1,
  "resultPlan": "n_result"
}*/

assign('user_input', '{{userInput}}')
n_result, act_xxx?param={{user_input}}
```

When LLM generation is needed, extend the skeleton with a referenced template:
```text
assign('user_input', '{{userInput}}')
n_result, tpl_main, psr_json

define('tpl_main', '''
根据输入完成任务：
{{user_input}}
直接返回 JSON，不要解释
''')
```

## Generation Workflow
1. Read requirement and map inputs to `parameter`.
2. Design plans with `n_xxx` names as jump targets.
3. Build chain with `expression(...)` or shorthand `rag_,tpl_,psr_,vrf_,act_`.
4. Add control flow (`when/elsewhen/foreach/on_failure`) when needed.
5. Define templates with strict output constraints (JSON/markdown/codeblock).
6. Add validation (`vrf_plan.checkAgent` or custom `vrf_*`) for generated code paths.
7. Set `resultPlan` to the final `n_xxx`.

## Grammar Essentials

### Variables and typing
- Use `assign('x','{{var}}')` for references.
- Use `assign('num','{{fn.raw(100)}}')` to keep number type.
- Use `append('var','v1','v2')` for concatenation.

### Plan chain
- Standard order: `rag -> tpl -> psr -> vrf -> act`.
- Shorthand line can only contain `rag_/tpl_/psr_/vrf_/act_/n_` comma list.
- `n_xxx` cannot be a standalone line; it must be part of a plan expression.

### Control flow
- `when('cond',{...},{...})` supports else block.
- `elsewhen({ ... })` means else.
- `foreach('loopVar','listOrCondition',{...})` supports list loop and conditional loop.
- Use `on_failure({ ... act_flow.go?plan=end })` for safe fallback.

### Flow jumping
- `act_flow.go?plan=` only supports `n_xxx` or `this/next/break/continue/end`.
- Do not jump by numeric index or custom labels.

### Templates
- Template names use `tpl_xxx`.
- Put `{{sys_hint}}` or `{{sys_hint_agt}}` when iterative correction is expected.
- For multi-turn chat:
  - `{{fn.chatFlag(maxLength)}}` or
  - `{{fn.chatFlag(systemPromptVar,userPromptVar,assistantPlanName,toolsetName,maxLength)}}`

### Parsing and validation
- Prefer `psr_json`, `psr_md`, `psr_all`, or combined forms like `psr_json_python`.
- For generated AgentFlow code, use:
  - `vrf_plan.checkAgent?type=groovy&script={{sys_last_result}}&checkTool=true`

## Extended Coverage

### File and artifact workflows
- Use `act_artifact.read` for files, URLs, mixed path lists, and line ranges.
- Use `act_artifact.write`, `append`, and `replaceLines` to edit files.
- Use `act_artifact.search`, `searchRows`, `readRows`, `list`, `exists`, `describe`, `syncState`, and `triggerSync` for discovery and index management.
- Treat `system/db/sql/{schema}/{table}` as the canonical path form for SQL-backed tables.
- Use `format=raw` for raw bytes and structured formats such as `markdown`, `map`, `matrix`, or `table` when they better match the downstream consumer.

### KB workflows
- Use `act_kb.defineKB` to create schemas, `importData` to seed data, and `hasKB` or `getKBDefinition` to inspect structure.
- Use `act_kb.search` and `searchQA` for semantic lookup.
- Use `act_kb.select`, `selectBy`, `update`, `merge`, and `delete` for table-style retrieval and mutations.
- Use `act_kbs.searchQuestion` for knowledge-space retrieval when the task spans folders or knowledge ids.

### Python matching workflows
- Use `act_python.writeTmp` or `act_python.write` to generate Python files, then run them with `act_python.run?filepath='{{n_file_info.kbspath}}'`.
- Use `act_python.readSimilar` when the task is to find the closest existing Python file or page object by requirement similarity.
- Prefer exact reuse before regeneration, and treat the returned match code as a similarity signal rather than business logic.

### Multi-turn chat workflows
- Use `fn.chatFlag(...)` for multi-turn prompt wrapping.
- When you need recent context, pair it with `fn.queryMessages` or `fn.queryRelevantHistoryText`.
- For chat-style agents, keep a clear separation between system prompt, user input, and the final answer variable, and use `define('tpl_xxx', ...)` only for referenced prompt templates.

### Task and RPG workflows
- Use `act_plan.parse` to turn markdown task lists into `n_plan_tasks`.
- Use `act_plan.assignAgent`, `act_plan.agent`, `act_plan.runPlan`, `act_plan.runAgent`, `act_plan.change`, `act_plan.addAgentHint`, and `act_memory.retrieve` when the task is decomposed into dynamic steps.
- Use `act_rpg.createAgent`, `run`, `snapshot`, `runFromSnapshot`, `forkAgent`, `rerun`, `getAgent`, `getPlanInfo`, `override`, `diff`, `traceDependency`, and `inspect` when rollback, branching, or execution tracing is needed.
- Prefer RPG when the user needs deep debugging, branching execution, or replay from a snapshot.

## Recommended Patterns

### Pattern A: Generate AgentFlow code from requirement
```text
assign('code_requirement', '{{userInput}}')
n_agent_script, tpl_gen_agent, psr_groovy, vrf_plan.checkAgent?type=groovy&script={{sys_last_result}}&checkTool=true
```

```text
define('tpl_gen_agent', '''
你是 AgentFlow 代码生成器。
根据需求输出可执行的 agt 脚本，仅返回代码，不要解释。
需求：
{{code_requirement}}

必须满足：
1) 文件结构为 metadata + plan + define
2) 变量引用使用 {{var}}
3) 至少有一个 n_xxx 结果 plan
''')
```

### Pattern B: Dynamic tool execution
```text
n_api_list, act_api.search?query='{{userInput}}'&size=5
tpl_choose_tool, psr_json
act_plan.run?toolType=API&code={{tpl_choose_tool.apiCode}}&parameters={{tpl_choose_tool.parameters}}
```

### Pattern C: Task list execution
```text
n_plan_tasks, act_plan.parse?task='{{task_markdown}}'
foreach('n_plan_tasks', 'n_plan_tasks', {
  act_plan.runPlan?executor=agt_executor&parameters='step_index={n_plan_tasks.index}'
})
```

## Frequent Pitfalls
- Using `if/for/return/def/it` in DSL blocks (not allowed).
- Mixing shorthand chain with `assign(...)` in same line.
- Forgetting `{{}}` around template variables.
- Writing string numbers in conditions without `fn.raw`.
- Using wrong placeholder style in `act_plan.runPlan` parameters (must use `{}` there).
- Defining jump target not prefixed with `n_`.
- Missing comment lines above each code line in `// 注释内容` format.

- Ignoring `act_artifact` for file and line-based editing, or `act_python` for Python file generation and matching.
- Ignoring `act_kb` / `act_kbs` for knowledge-base tasks and `act_rpg` for replay, snapshot, and trace-heavy debugging.

## Minimal Quality Checklist
- [ ] File name matches `agt*.txt`.
- [ ] Metadata block exists and parameters are complete.
- [ ] Main output plan uses `n_xxx`.
- [ ] Template output format is explicit (JSON/MD/codeblock).
- [ ] Variable placeholders use `{{}}`.
- [ ] Flow jumps only use allowed plan targets.
- [ ] If code is LLM-generated, `vrf_plan.checkAgent` is present.
- [ ] Every AgentFlow code line has a `// 注释内容` comment line immediately above it.
- [ ] Every `define('tpl_xxx', ...)` is referenced at least once by an executable chain; remove unused defines.

## When To Apply This Skill
Apply this skill when user asks to:
- create an AgentFlow/Agent script;
- convert requirement/doc into `agt` code;
- add or refactor `define/tpl/psr/vrf/act` chains;
- repair AgentFlow grammar or plan-jump issues.
