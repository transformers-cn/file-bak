# -*- coding: utf-8 -*-
# PERSONAL 与agent存放路径相关，默认为True，表示智能体文件存放在个人空间；如果为False，则存放在公共空间
PERSONAL = True
BASE_URL = "http://172.18.3.11:8180/gw/agent"
KB_BASE_URL = "http://172.18.3.11:5171/api/gw/run/api"
#  账号
HEADERS = {
    'Authorization': 'Bearer sk-EmZ4E3X-TYumyPB73KG-IXlcneVYthoP'
}
WEB_HEADERS = HEADERS.copy()



class APIConfig:
    def __init__(self, base_url=None, headers=None, web_headers=None, personal=None):
        self.base_url = base_url or BASE_URL
        self.headers = headers or HEADERS
        self.web_headers = web_headers or WEB_HEADERS
        self.personal = personal or PERSONAL
    
    def get_url(self, endpoint):
        return f"{self.base_url}{endpoint}"
    
    def get_headers(self):
        return self.headers


config = APIConfig()
